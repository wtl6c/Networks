William Trace LaCour (WTL6C)
Justin Vaughn Javier (JTJ5GS)

CS/ECE 4457 - Spring 2019
Project #3 - Reliable Transport

------- SUBMISSION -------

Files submitted 
	- entity.c (added functions to make code a bit more readable)
	- entity.h (NEED THIS)
	- output.txt (output of program, mainly the print statements)
	- test1.txt (input for program)
	- README_submission_explanations.txt
	- output.dat (just in case you wanted it)


------- NOTES -------

Program needs the entity.h file due to some added functions. Sorry :(

Program will work with any amount of characters in the input file, any seed, packet loss, corruption, and/or interval... That I tested. Not saying it's unbreakable but its stable... ish.

The output.txt file holds the output transcript of the program when given the test1.txt file as an input. The transcript is quite long but to me and to any potential employer of mine, length should not be an issue. This was the only way for me to verify full functionality. I commented out a few of the useless print statements that I had during testing but left the essential ones, as well as the ones that were asked for in the submission document on collab. I hope this will suffice. 